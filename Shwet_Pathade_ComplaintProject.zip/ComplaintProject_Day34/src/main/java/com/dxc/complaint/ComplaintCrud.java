
package com.dxc.complaint;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;


public class ComplaintCrud {
	
	public String registerComp(Complaint complaint) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
		ht.save(complaint);
		return "Complaint Registered...";
	}
	
	public Complaint searchComplaint(int complaintId) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
		Complaint complaint = null;
		List<Complaint >compList = (List<Complaint>) ht.find("from Complaint where complaintId="+complaintId);
		if (compList.size() > 0) {
			complaint = compList.get(0);
		}
		return complaint;
	}
	 
	public List<Complaint> showComplaints() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
		List<Complaint> compList = ht.find("from Complaint");
		return compList;
	
	}
	
	public List<Integer> pending() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
	    List<Complaint> lstComplaint=ht.find("from Complaint where Cstatus='PENDING'");
	    List<Integer> lstPending=new ArrayList<Integer>();
	    for(Complaint b : lstComplaint){
	    	lstPending.add(b.getComplaintId());
	    }
	    return lstPending;
	}
	
	public String resolveComplaint(Resolve resolve) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
		
		ht.save(resolve);
		int count = resolve.getComplaintId();
		Complaint comp = null;
		List<Complaint> compList = ht.find("from Complaint where complaintId="+count);
		if(compList.size()>0) {
			
			comp = compList.get(0);
		}
		comp.setcStatus("RESOLVED");
		ht.merge(comp);
		return "Complaint Resolved...";
		
	}
	
	public int tatCount() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
		List lst=ht.find("select DATEDIFF(Cdate,CURDATE()) from Complaint where cstatus='PENDING'");
		int tatcount=0;
		for(Object ob : lst){
			tatcount=(Integer)ob;
		}
		return tatcount;
		
	}
	
	
	public void updateTat(Complaint comp) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
		ht.merge(comp);
	}
	
	
	public List<Complaint> pendingComp() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("application-context.xml");
		HibernateTemplate ht=(HibernateTemplate)ctx.getBean("hibernateTemplate");
	    List<Complaint> lstComplaint=ht.find("from Complaint where Cstatus='PENDING'");
	    return lstComplaint;
	}

	
	
	
	


}
