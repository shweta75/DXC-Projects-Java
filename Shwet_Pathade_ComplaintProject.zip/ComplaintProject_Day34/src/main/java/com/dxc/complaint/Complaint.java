package com.dxc.complaint;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Complaint")
public class Complaint {
	
	private int complaintId;
	private String complaintType;
	private String description;
	private String cDate;
	private int tat;
	private int severity;
	private String cStatus;
	
	@Id
	@Column(name="complaintId")
	public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	
	@Column(name="ComplaintType")
	public String getComplaintType() {
		return complaintType;
	}
	public void setComplaintType(String complaintType) {
		this.complaintType = complaintType;
	}
	
	@Column(name="Description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name="CDate")
	public String getcDate() {
		return cDate;
	}
	public void setcDate(String cDate) {
		this.cDate = cDate;
	}
	
	@Column(name="Tat")
	public int getTat() {
		return tat;
	}
	public void setTat(int tat) {
		this.tat = tat;
	}
	
	@Column(name="Severity")
	public int getSeverity() {
		return severity;
	}
	public void setSeverity(int severity) {
		this.severity = severity;
	}
	
	@Column(name="Cstatus")
	public String getcStatus() {
		return cStatus;
	}
	public void setcStatus(String cStatus) {
		this.cStatus = cStatus;
	}
	
	
	

}
