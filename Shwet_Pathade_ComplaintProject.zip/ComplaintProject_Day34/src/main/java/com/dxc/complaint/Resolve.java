package com.dxc.complaint;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Resolve")
public class Resolve {

	private int rid;
	private String resolvedBy;
	private String rComments;
	private int complaintId;
	
	@Id
	@Column(name="Rid")
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	
	@Column(name="ResolvedBy")
	public String getResolvedBy() {
		return resolvedBy;
	}
	public void setResolvedBy(String resolvedBy) {
		this.resolvedBy = resolvedBy;
	}
	
	@Column(name="RComments")
	public String getrComments() {
		return rComments;
	}
	public void setrComments(String rComments) {
		this.rComments = rComments;
	}
	
	@Column(name="ComplaintID")
	public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
		
	
}
