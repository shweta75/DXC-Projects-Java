NoOfQuen = 20;
var Questions = Array(NoOfQuen);
var Answers = new Array(NoOfQuen);

Selected = false;

for(var i = 0 ; i<NoOfQuen ; i++){
	Answers[i] = new Array(19);
	
} 

var CorrectAnswers = new Array(NoOfQuen);


QuestionNo = 0;
Score = 0;
OptionSelected = 0;
Answer = 20;


function AnsSelected(Ans){
	Answer = Ans;
	Selected = true;
}



// Call load function

function load(){
	loadQuestion();
}



function loadQuestion(){

	document.getElementById("Questions").innerHTML = "[" + (QuestionNo + 1) + "] " + Questions[QuestionNo]; //
	
	document.getElementById("option0").innerHTML = "[a] " + Answers[QuestionNo][0];
	document.getElementById("option1").innerHTML = "[b] " + Answers[QuestionNo][1];
	document.getElementById("option2").innerHTML = "[c] " + Answers[QuestionNo][2];
	document.getElementById("option3").innerHTML = "[d] " + Answers[QuestionNo][3];
	
	
	
	document.getElementById("op1").checked = false;
	document.getElementById("op2").checked = false;
	document.getElementById("op3").checked = false;
	document.getElementById("op4").checked = false;
	
	Answer = 20;
}


function NextQuestion(){
	
	if(Answer == CorrectAnswers[QuestionNo]){
	
		Score++;
	}
	if(Selected){
		
		if(QuestionNo < NoOfQuen - 1){
			QuestionNo++;
			loadQuestion();
		}else{
			
			alert("Exam is Over \n" + "Score : " + Score + "");
		}
		Selected = false;
	}else{
		
		alert("Please select an option...");
	}
	
}


Questions[0] = "In which decade was the Internet first implemented?";
Answers[0][0] = "1940s";
Answers[0][1] = "1950s";
Answers[0][2] = "1960s";
Answers[0][3] = "1980s";
CorrectAnswers[0] = 3;


Questions[1] = "Main circuit board in a computer is : ";
Answers[1][0] = "Decoder";
Answers[1][1] = "Highlight";
Answers[1][2] = "Select";
Answers[1][3] = "Mother board";
CorrectAnswers[1] = 4;



Questions[2] = "ISP stands for :";
Answers[2][0] = "Internet Survey Period";
Answers[2][1] = "Integrated Service Provider";
Answers[2][2] = "Internet Security Protocol";
Answers[2][3] = "Internet Service Provider";
CorrectAnswers[2] = 4;




Questions[3] = "Which company created the most used networking software in the 1980's";
Answers[3][0] = "Microsoft";
Answers[3][1] = "Sun";
Answers[3][2] = "IBM";
Answers[3][3] = "Novell";
CorrectAnswers[3] =  2;



Questions[4] = "Which of the following operating systems is produced by IBM?";
Answers[4][0] = "OS-2";
Answers[4][1] = "Windows";
Answers[4][2] = "DOS";
Answers[4][3] = "UNIX";
CorrectAnswers[4] =  1;



Questions[5] = "In what year was the '@' chosen for its use in e-mail addresses?";
Answers[5][0] = "1972";
Answers[5][1] = "1976";
Answers[5][2] = "1980";
Answers[5][3] = "1984";
CorrectAnswers[5] =  1;



Questions[6] = "Where is the headquarters of Intel located?";
Answers[6][0] = "Redmond, Washington";
Answers[6][1] = "Tucson, Arizona";
Answers[6][2] = "Santa Clara, California";
Answers[6][3] = "Richmond, Virginia";
CorrectAnswers[6] = 3 ;



Questions[7] = "Who co-created the UNIX operating system in 1969 with Dennis Ritchie?";
Answers[7][0] = "Bjarne Stroustrup";
Answers[7][1] = "Steve Wozniak";
Answers[7][2] = "Ken Thompson";
Answers[7][3] = "Niklaus Wirth";
CorrectAnswers[7] =  3;


Questions[8] = "Which of the following is not a computer language?";
Answers[8][0] = "Windows 98";
Answers[8][1] = "PASCAL";
Answers[8][2] = "FORTRAN";
Answers[8][3] = "C++";
CorrectAnswers[8] =  1;


Questions[9] = " The first web server was built in:";
Answers[9][0] = "1990 in Geneva, Switzerland";
Answers[9][1] = "1985 in Berkeley, California";
Answers[9][2] = "1988 in Cambridge, Massachusetts";
Answers[9][3] = "1947 in Birmingham, UK";
CorrectAnswers[9] =  1;



Questions[10] = "In what year did the Symantec Corporation first release Norton Anti-virus?";
Answers[10][0] = "1990";
Answers[10][1] = "1995";
Answers[10][2] = "1988";
Answers[10][3] = "1997";
CorrectAnswers[10] =  1;



Questions[11] = "Which of the following word processors came first?";
Answers[11][0] = "Word Perfect";
Answers[11][1] = "Lotus Notes";
Answers[11][2] = "MS Word";
Answers[11][3] = "Word Star";
CorrectAnswers[11] =  4;


Questions[12] = "In 1983, which person was the first to offer a definition of the term 'computer virus'?";
Answers[12][0] = "McAfee";
Answers[12][1] = "Smith";
Answers[12][2] = "Cohen";
Answers[12][3] = "Norton";
CorrectAnswers[12] =  3;



Questions[13] = "The first graphical browser for the WWW was named:";
Answers[13][0] = "Netscape";
Answers[13][1] = "Veronica";
Answers[13][2] = "Mosaic";
Answers[13][3] = "Explorer";
CorrectAnswers[13] =  3;




Questions[14] = "Who among the following considered as the 'father of artificial intelligence'?";
Answers[14][0] = "Charles Babbage";
Answers[14][1] = "Lee De Forest";
Answers[14][2] = "John McCarthy";
Answers[14][3] = "JP Eckert";
CorrectAnswers[14] =  3;




Questions[15] = "Who among the following used the term computer worm for the first time?";
Answers[15][0] = "John Brunner";
Answers[15][1] = "Alan Turing";
Answers[15][2] = "John McCarthy";
Answers[15][3] = "JP Eckert";
CorrectAnswers[15] =  1;



Questions[16] = "Which of these is not a programming language?";
Answers[16][0] = "BASIC";
Answers[16][1] = "COBOL";
Answers[16][2] = "BNF";
Answers[16][3] = "FORTRAN";
CorrectAnswers[16] =  3;



Questions[17] = "What does the command prompt uses?";
Answers[17][0] = "CLI (Command Line Interface)";
Answers[17][1] = "GUI (Graphical User Interface).";
Answers[17][2] = "Text User Interface TUI";
Answers[17][3] = "None of the above";
CorrectAnswers[17] =  1;



Questions[18] = "Which out of the following helps in quickly help you rename a file or folder?";
Answers[18][0] = "F2";
Answers[18][1] = "F0";
Answers[18][2] = "F8";
Answers[18][3] = "F9";
CorrectAnswers[18] =  1;



Questions[19] = "Who developed Yahoo?";
Answers[19][0] = "Dennis Ritchie & Ken Thompson";
Answers[19][1] = "David Filo & Jerry Yang";
Answers[19][2] = "Vint Cerf & Robert Kahn";
Answers[19][3] = "Steve Case & Jeff Bezos";
CorrectAnswers[19] =  2;



Questions[20] = "Which of these is a documented hoax virus?";
Answers[20][0] = "McDonalds screensaver";
Answers[20][1] = "Alien.worm";
Answers[20][2] = "Merry Xmas";
Answers[20][3] = "Adolph";
CorrectAnswers[20] =  1;













