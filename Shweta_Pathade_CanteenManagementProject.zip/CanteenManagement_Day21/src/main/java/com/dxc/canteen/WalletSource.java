package com.dxc.canteen;

public enum WalletSource {

	PAYTM,DEBIT_CARD,CREDIT_CARD
	
}
