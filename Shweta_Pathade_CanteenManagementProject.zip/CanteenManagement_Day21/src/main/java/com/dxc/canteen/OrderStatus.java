package com.dxc.canteen;

public enum OrderStatus {

	PENDING, ACCEPTED, DENIED

}
