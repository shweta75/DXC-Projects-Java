/*
var i = 0;
var images = [];
var time = 2000;	

images[0] = home.jpg;
images[1] = office.jpg;
images [2] = startup.jpg;


function background(){
	document.body.src = images[i];
	
	if(i<images.length - 1){
		i++;
	}else{
		i = 0;
	}

	setTimeout("background()", time);
	LoadQuestion();	
}
*/


function background()
{
	var imgs = new Array("home.jpg", "office.jpg",
 		"startup.jpg");

	var random = Math.floor(Math.random()*3);
	
	document.body.background = imgs[random];
	LoadQuestion();
	
}


question = 0;
function LoadQuestion()
{
    var x = document.getElementById("previousQstn");
    document.getElementById("submit").style.display = "none";
    document.getElementById("nextQstn").style.display = "inline";
    if (question == 0) {
        x.style.display = "none";
    } else {
        x.style.display = "inline";
    }
    if (question == 2) {
        document.getElementById("submit").style.display = "inline";
        document.getElementById("nextQstn").style.display = "none";
    }
    document.getElementById('tab1').style.backgroundColor = '#F98B88';
}

function Previous() {
    question--;
    background();
    if (document.getElementById('previousQstn').name == 'personal') {
        document.getElementById('nextQstn').name = 'qualification';
        document.getElementById('previousQstn').name = 'Step0';
        document.getElementById('personal').style.display = 'inline';
        document.getElementById('qualification').style.display = 'none';
        document.getElementById('tab1').style.backgroundColor = '#F98B88';
        document.getElementById('tab2').style.backgroundColor = 'Silver';
        
    } else if (document.getElementById('previousQstn').name == 'qualification') {
        document.getElementById('nextQstn').name = 'skills';
        document.getElementById('previousQstn').name = 'personal';
        document.getElementById('qualification').style.display = 'inline';
        document.getElementById('skills').style.display = 'none';
        document.getElementById('tab2').style.backgroundColor = '#F98B88';
        document.getElementById('tab3').style.backgroundColor = 'Silver';
        document.getElementById('tab1').style.backgroundColor = 'Silver';
    }
}

function Next()
{
    question++;
    background();
    if (document.getElementById('nextQstn').name == 'qualification') {
        document.getElementById('nextQstn').name = 'skills';
        document.getElementById('previousQstn').name = 'personal';
        document.getElementById('qualification').style.display = 'inline';
        document.getElementById('tab1').style.backgroundColor = 'Silver';
        document.getElementById('personal').style.display = 'none';
        document.getElementById('tab2').style.backgroundColor = '#F98B88';
        
    } else if (document.getElementById('nextQstn').name == "skills") {
        document.getElementById('nextQstn').name = 'review';
        document.getElementById('previousQstn').name = 'qualification';
        document.getElementById('skills').style.display = 'inline';
        document.getElementById('tab2').style.backgroundColor = 'Silver';
        document.getElementById('qualification').style.display = 'none';
        document.getElementById('tab1').style.backgroundColor = 'Silver';
        document.getElementById('tab3').style.backgroundColor = '#F98B88';
        
    }
}

function summary() {

    document.getElementById('chkFirstName').innerHTML = document.getElementById('TextFirstName').value;

    document.getElementById('chkMiddleName').innerHTML = document.getElementById('TextMiddleName').value;

    document.getElementById('chkLastName').innerHTML = document.getElementById('TextLastName').value;

    document.getElementById('chkQualification').innerHTML = document.getElementById('TextQualification').value;
    
    if (document.getElementById('chkHtml').checked == 1) {

        document.getElementById('selectHtml').innerHTML = 'Yes';

    }else {

        document.getElementById('selectHtml').innerHTML = 'No';

    }

    if (document.getElementById('chkPython').checked == 1) {

        document.getElementById('selectPython').innerHTML = 'Yes';

    }else {

        document.getElementById('selectPython').innerHTML = 'No';

    }

    if (document.getElementById('chkCss').checked == 1) {

        document.getElementById('selectCss').innerHTML = 'Yes';

    }else {

        document.getElementById('selectCss').innerHTML = 'No';

    }

    if (document.getElementById('chkJava').checked == 1) {

        document.getElementById('selectJava').innerHTML = 'Yes';

    }else {

        document.getElementById('selectJava').innerHTML = 'No';

    }
    if (document.getElementById('chkCloud').checked == 1) {

        document.getElementById('selectCloud').innerHTML = 'Yes';

    }else {

        document.getElementById('selectCloud').innerHTML = 'No';

    }
    if (document.getElementById('chkAi').checked == 1) {

        document.getElementById('selectAi').innerHTML = 'Yes';

    }else {

        document.getElementById('selectAi').innerHTML = 'No';

    }
}


function showSummary() {
    background();
    document.getElementById('tab3').style.backgroundColor = 'Silver';
    document.getElementById('tab4').style.backgroundColor = '#F98B88';
    document.getElementById('tab1').style.backgroundColor = 'Silver';
    document.getElementById('skills').style.display = 'none';
    document.getElementById('review').style.display = 'inline';
    document.getElementById("previousQstn").style.display = "none";
    document.getElementById("submit").style.display = "none";
    
    summary();
}